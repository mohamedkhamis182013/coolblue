﻿namespace Insurance.Application.UseCases.ProductInsurance.Queries.GetProducInsurance;

public class ProducInsuranceVm
{
    public int ProductId { get; set; }
    public float InsuranceValue { get; set; }
}
