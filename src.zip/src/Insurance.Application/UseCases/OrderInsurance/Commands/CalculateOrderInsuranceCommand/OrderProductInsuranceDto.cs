﻿namespace Insurance.Application.UseCases.OrderInsurance.Commands.CalculateOrderInsuranceCommand;

public class OrderProductInsuranceDto
{
    public int ProductId { get; set; }

    public int Quantity { get; set; }

}
